# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['gamma']

package_data = \
{'': ['*']}

install_requires = \
['Click>=7.0,<8.0',
 'Pandas>=0.23.4,<0.24.0',
 'beautifulsoup4>=4.7,<5.0',
 'colorama>=0.4.1,<0.5.0',
 'jinja2>=2.10,<3.0',
 'path.py>=11.5,<12.0',
 'python-frontmatter>=0.4.4,<0.5.0',
 'tabulate>=0.8.2,<0.9.0',
 'xlsxwriter>=1.1,<2.0']

entry_points = \
{'console_scripts': ['gamma = gamma.main:gamma']}

setup_kwargs = {
    'name': 'gamma-cli',
    'version': '0.1.14',
    'description': 'Command line tool for Gamma curriculum.',
    'long_description': None,
    'author': 'artificialsoph',
    'author_email': 's@soph.info',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
